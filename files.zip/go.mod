module github.com/SobhanYasami/GoMasterHttpRelayVPN

go 1.22.2
